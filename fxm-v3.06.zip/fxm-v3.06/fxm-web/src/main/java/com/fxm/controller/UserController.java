package com.fxm.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.fxm.pojo.User;
import com.fxm.service.DubboUserService;
import com.fxm.vo.CookieVO;
import com.fxm.vo.SysResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import redis.clients.jedis.JedisCluster;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/user")
public class UserController {

    @Reference(check = false)
    private DubboUserService dubboUserService;

    @Autowired
    private JedisCluster jedisCluster;


    @RequestMapping("/{moduleName}")
    public String moduleName(@PathVariable String moduleName) {
        return moduleName;
    }

    @RequestMapping("/doRegister")
    @ResponseBody
    public SysResult doRegister(User user) {
        try {
            dubboUserService.saveUser(user);
            return SysResult.success();
        }catch (Exception e) {
            e.printStackTrace();
            return SysResult.fail();
        }
    }
    @RequestMapping("/doLogin")
    @ResponseBody
    public SysResult doLogin(User user,  HttpServletResponse res) {
        String uuid = dubboUserService.valid(user);

        if(StringUtils.isEmpty(uuid))return SysResult.fail();

        Cookie ticket = CookieVO.setCookie("FXM_TICKET", uuid);
        res.addCookie(ticket);
        return SysResult.success();
    }

    @RequestMapping("/logout")
    public String doLogout(HttpServletRequest req, HttpServletResponse res) {
        Cookie[] cookies = req.getCookies();
        if(cookies==null||cookies.length==0)return "redirect:/";

        String ticket = null;
        for (Cookie ck : cookies) {
            if("FXM_TICKET".equals(ck.getName())){
                ticket = ck.getValue();
                break;
            }
        }
        if(StringUtils.isEmpty(ticket))return "redirect:/";
        jedisCluster.del(ticket);
        Cookie ck = CookieVO.setCookie("FXM_TICKET", "");
        res.addCookie(ck);
        return "redirect:/";
    }


}
