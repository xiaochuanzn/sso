package com.fxm.vo;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import javax.servlet.http.Cookie;
import java.util.HashSet;
import java.util.Set;

@Configuration
public class CookieVO {

    private final static Integer seven_day = 7 * 24 * 3600;
    private final static String url = "www.fxm.com";
    public CookieVO() {
    }

    public static Cookie setCookie(String key, String value) {
        Cookie cookie = new Cookie(key,value);
        cookie.setMaxAge(seven_day);
        cookie.setDomain(url);
        cookie.setPath("/");
        return cookie;
    }

    public static Cookie removeCookie(String key, String value) {
        Cookie cookie = new Cookie(key,value);
        cookie.setMaxAge(0);
        cookie.setDomain(url);
        cookie.setPath("/");
        return cookie;
    }
}
