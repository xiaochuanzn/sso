package com.fxm.service;

import com.fxm.pojo.User;

public interface DubboUserService {

	void saveUser(User user);

    String valid(User user);
}
