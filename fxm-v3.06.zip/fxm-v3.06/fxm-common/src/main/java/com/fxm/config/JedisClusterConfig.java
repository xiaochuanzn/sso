package com.fxm.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;

import java.util.HashSet;
import java.util.Set;

@Configuration
@PropertySource("classpath:/properties/redis.properties")
public class JedisClusterConfig {
    @Value("${redis.node}")
    private String node;

    @Bean
    public JedisCluster jedisCluster(){
        Set<HostAndPort> hap = new HashSet<>();

        String[] str = node.split(",");
        for (String s : str) {
            String host = s.split(":")[0];
            Integer port = Integer.parseInt(s.split(":")[1]);
            HostAndPort hostAndPort = new HostAndPort(host,port);
            hap.add(hostAndPort);
        }
        return new JedisCluster(hap);
    }
}
