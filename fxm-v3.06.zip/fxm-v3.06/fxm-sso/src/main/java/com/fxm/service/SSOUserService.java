package com.fxm.service;

public interface SSOUserService {

    boolean checkUser(String name, Integer type);
}
