package com.fxm.controller;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.fxm.service.SSOUserService;
import com.fxm.util.ObjectMapperUtil;
import com.fxm.vo.CookieVO;
import com.fxm.vo.SysResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import redis.clients.jedis.JedisCluster;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

@RestController
@RequestMapping("/user")
public class SSOUserController {

    @Autowired
    private SSOUserService ssoUserService;

    @Autowired
    private JedisCluster jedisCluster;

    @RequestMapping("check/{name}/{type}")
    public JSONPObject checkUser(@PathVariable String name, @PathVariable Integer type,
                                 String callback) {
        JSONPObject jsonpObject = null;
        try {
            boolean flag = ssoUserService.checkUser(name, type);
            jsonpObject = new JSONPObject(callback, SysResult.success());
        } catch (Exception e) {
            e.printStackTrace();
            jsonpObject = new JSONPObject(callback,SysResult.fail());
        }

        return jsonpObject;
    }

    /**
     * @param ticket
     * @param res
     * @param callback
     * @return
     * redis tk is null?del:call
     */
    @RequestMapping("/query/{ticket}")
    public JSONPObject query(@PathVariable String ticket, HttpServletResponse res, String callback){
        JSONPObject jsonpObject =null;
        String tk = jedisCluster.get(ticket);
        if(StringUtils.isEmpty(tk)){
            Cookie ck = CookieVO.removeCookie("FXM_TICKET", "");
            res.addCookie(ck);
            jsonpObject = new JSONPObject(callback,SysResult.fail());

        }else {
            jsonpObject = new JSONPObject(callback,SysResult.success(tk));
        }
        return jsonpObject;
    }
}
