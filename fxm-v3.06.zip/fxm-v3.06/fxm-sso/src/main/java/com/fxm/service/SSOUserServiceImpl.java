package com.fxm.service;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.fxm.mapper.UserMapper;
import com.fxm.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class SSOUserServiceImpl implements SSOUserService{

    @Autowired
    private UserMapper userMapper;

    @Override
    public boolean checkUser(String name, Integer type) {
        Map<Integer,String> map = new HashMap<>();
        map.put(1,"username");
        map.put(2,"phone");
        map.put(3,"email");

        QueryWrapper<User> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq(map.get(type),name);

        User user = userMapper.selectOne(queryWrapper);

        return user==null?false:true;
    }

}
